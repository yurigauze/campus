

import 'package:campus/src/controles/database/firestore/avisos_dao_firestore.dart';
import 'package:campus/src/controles/interface/aviso_dao_interface.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
