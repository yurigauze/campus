import 'package:flutter/material.dart';

class TecnicoSubsequente extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text("Tecnico Subsequente")), body: null);
  }
}
