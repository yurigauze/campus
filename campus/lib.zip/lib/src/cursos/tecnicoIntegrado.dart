import 'package:flutter/material.dart';

class TecnicoIntegrado extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text("Tecnico Integrado")), body: null);
  }
}
