import 'package:flutter/material.dart';

class CursoSuperior extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text("Curso Superior")), body: null);
  }
}
