import 'package:flutter/material.dart';

class Administracao extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Administracao")), 
        body: null);
  }
}
