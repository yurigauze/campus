import 'package:flutter/material.dart';

class laboratorios extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Laboratorio")), body: null);
  }
}
