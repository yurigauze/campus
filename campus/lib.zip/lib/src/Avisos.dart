import 'package:flutter/material.dart';


class Avisos extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Avisos")), 
        body: null);
  }
}
